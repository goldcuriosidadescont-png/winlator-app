# Third-party components

Cerberus PC's application architecture and integration code are authored for this project. The following upstream projects are runtime components, not source bases for the Cerberus Android app.

## X.Org X server / Xvfb
- Purpose: X11 server and XWD framebuffer backend.
- Project: X.Org Server 21.1.x.
- License: MIT/X11 family; preserve upstream package notices/licenses when redistributing.
- Build source used by the CI packager: Termux package repositories, whose `xorg-server` recipe declares MIT and builds upstream X.Org sources.

## X11 client libraries
- Purpose: dependencies required by Wine `winex11` and Xvfb runtime.
- Components include libX11, libXext and dependency closure resolved by CI.
- Licenses remain those of each upstream X.Org component.

## Box64
- Purpose: x86-64 userspace translation on ARM64/Bionic.
- Version selected by this branch: Box64 0.4.4 Bionic package.
- License and attribution remain upstream Box64/package-provider terms.

## Proton Wine
- Purpose: Win32/Win64 compatibility layer.
- Version selected by this branch: Proton Wine 11.0-2 x86_64 package.
- Wine/Proton and bundled libraries retain their respective upstream licenses.

## Non-copying rule
No Winlator or Termux:X11 Android Activity, Fragment, container manager, launcher manager, Java/JNI application framework, layout or branded UI is incorporated into this repository. Upstream runtime components may implement standard protocols or ABIs; Cerberus integration around them is independent project code.
