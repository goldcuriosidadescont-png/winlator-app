package dev.cerberus.pc;

import android.content.Context;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

final class ContainerStore {
    private final File root;

    ContainerStore(Context context) throws IOException {
        root = new File(context.getFilesDir(), "cerberus/containers");
        if (!root.isDirectory() && !root.mkdirs()) throw new IOException("Falha criando armazenamento de containers");
    }

    List<ContainerProfile> list() {
        ArrayList<ContainerProfile> result = new ArrayList<>();
        File[] dirs = root.listFiles(File::isDirectory);
        if (dirs == null) return result;
        Arrays.sort(dirs, Comparator.comparingLong(File::lastModified).reversed());
        for (File dir : dirs) {
            File profile = new File(dir, ContainerProfile.FILE_NAME);
            if (!profile.isFile()) continue;
            try { result.add(ContainerProfile.load(dir)); } catch (IOException ignored) { }
        }
        return result;
    }

    ContainerProfile create(String name, String resolution, String display, String preset) throws IOException {
        return ContainerProfile.create(root, name, resolution, display, preset);
    }

    ContainerProfile find(String id) throws IOException {
        if (id == null || !id.matches("c-[a-fA-F0-9]{12}")) throw new IOException("ID de container inválido");
        File dir = new File(root, id);
        File profile = new File(dir, ContainerProfile.FILE_NAME);
        if (!profile.isFile()) throw new IOException("Container não encontrado: " + id);
        return ContainerProfile.load(dir);
    }

    void delete(ContainerProfile profile) throws IOException {
        deleteRecursive(profile.dir);
    }

    private static void deleteRecursive(File f) throws IOException {
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        if (f.exists() && !f.delete()) throw new IOException("Não foi possível excluir " + f.getAbsolutePath());
    }
}
