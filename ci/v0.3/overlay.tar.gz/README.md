# Cerberus PC v0.3.0 — Display Runtime

Cerberus PC is a clean-room Android ARM64 Windows compatibility project. Its Android application, container model, session lifecycle, X11 protocol client, framebuffer transport and input bridge are Cerberus-owned code; third-party runtimes are consumed as replaceable upstream components rather than used as an application base.

## v0.3 Display Runtime

- Persistent containers from v0.2 remain isolated per Wine prefix, C:, HOME, TMP, logs and state.
- Box64 0.4.4 Bionic translates the x86-64 Wine userspace on ARM64.
- Proton Wine 11.0-2 x86_64 provides the Windows compatibility layer.
- X.Org Xvfb 21.1.16 is packaged as the X11 server component for the first Cerberus display backend.
- `winex11.drv` connects to the local per-container X11 display over loopback TCP.
- Cerberus maps Xvfb's XWD framebuffer and presents it in its own Android `SurfaceView`.
- Cerberus owns a small raw X11/XTEST client for absolute pointer motion, mouse buttons/wheel and keyboard injection.
- Single-touch = left click/drag; quick two-finger tap = right click; Android mouse and hardware/software keyboard are bridged to X11.
- No root requirement.

## Architecture boundary

This repository does **not** import Winlator or Termux:X11 Activities, container managers, Java/JNI application architecture or UI. X.Org/libX11/libXext and their runtime dependencies are resolved from upstream/Termux-built packages during CI, verified from repository SHA256 metadata, and treated as third-party components. See `THIRD_PARTY.md`.

The v0.3 XWD path is intentionally a correctness-first software display backend. It is not yet the final high-performance GPU path. The planned next graphics stage is a Cerberus-owned GPU/display integration around upstream Turnip/Zink plus DXVK/VKD3D, followed by audio and game-controller work.

## Build validation

GitHub Actions runs the native core sanitizers, JNI bridge tests, downloads and verifies Box64/Proton/X11 components, resolves ELF dependency closure, builds the ARM64 APK, runs Android lint and inspects the final APK payload. Device-side graphical rendering still requires validation on real hardware because CI cannot emulate the S23 GPU/input/display environment.
